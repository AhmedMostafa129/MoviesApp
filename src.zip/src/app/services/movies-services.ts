import { Injectable } from '@angular/core';
import { Movies } from '../modals/movies';

@Injectable({
  providedIn: 'root',
})
export class MoviesServices {
  movie: Movies[];

  constructor() {
    this.movie = [
      { id: 1, name: "John-Wick", rate: 8, availablelty: "available", categoryId: 1, image: "2.jpg" },
      { id: 2, name: "Jocker", rate: 8, availablelty: "available", categoryId: 1, image: "22.jpg" },
      { id: 3, name: "Fast & Furious", rate: 8.5, availablelty: "available", categoryId: 1, image: "11.webp" },
      { id: 4, name: "Land Of Bad", rate: 9, availablelty: "available", categoryId: 1, image: "111.jpg" },
      { id: 5, name: "Expendables 2", rate: 9.5, availablelty: "available", categoryId: 1, image: "1111.jpg" },
      { id: 6, name: "MAMA", rate: 8, availablelty: "available", categoryId: 4, image: "8.jpg" },
      { id: 7, name: "قلب أمـــه", rate: 8, availablelty: "available", categoryId: 2, image: "6.jpg" },
      { id: 8, name: "مربع برمودة", rate: 8, availablelty: "available", categoryId: 2, image: "7.webp" },
      { id: 9, name: "المصيــر", rate: 8, availablelty: "available", categoryId: 3, image: "3.jpeg" },
      { id: 10, name: "Cargo", rate: 8, availablelty: "available", categoryId: 3, image: "5.jpg" },
      { id: 11, name: "harry", rate: 8, availablelty: "available", categoryId: 5, image: "harry.webp" },
    ];
  }

  getAllmovies(): Movies[] {
    return this.movie;
  }

  getMovieById(id: number): Movies | undefined {
    return this.movie.find(movie => movie.id === id);
  }

  // دالة الأفلام الموصى بها
  getRecommendedMovies(categoryId: number, excludeMovieId: number): Movies[] {
    return this.movie.filter(m => m.categoryId === categoryId && m.id !== excludeMovieId);
  }
}
