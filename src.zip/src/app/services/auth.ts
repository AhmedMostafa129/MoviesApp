import { Injectable, signal, inject } from '@angular/core';
import { Router } from '@angular/router';

interface User {
  email: string;
  name: string;
  password: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private router = inject(Router);

  private loggedIn = signal(false);
  private user = signal<User | null>(null);

  constructor() {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      this.user.set(JSON.parse(storedUser));
      this.loggedIn.set(true);
    }
  }

  // تسجيل الدخول
  login(email: string, password: string): boolean {
    const registered = localStorage.getItem('registeredUsers');
    if (!registered) return false;

    const users: User[] = JSON.parse(registered);
    const found = users.find(u => u.email === email && u.password === password);

    if (found) {
      this.user.set(found);
      this.loggedIn.set(true);
      localStorage.setItem('currentUser', JSON.stringify(found));
      return true;
    }

    return false;
  }

  // تسجيل مستخدم جديد
  register(email: string, name: string, password: string): void {
    const newUser: User = { email, name, password };

    // جلب كل المستخدمين السابقين
    const registered = localStorage.getItem('registeredUsers');
    let users: User[] = registered ? JSON.parse(registered) : [];

    // تحقق من عدم تكرار الإيميل
    const exists = users.find(u => u.email === email);
    if (exists) {
      throw new Error('Email already registered');
    }

    users.push(newUser);
    localStorage.setItem('registeredUsers', JSON.stringify(users));

    this.user.set(newUser);
    this.loggedIn.set(true);
    localStorage.setItem('currentUser', JSON.stringify(newUser));
  }

  logout(): void {
    localStorage.removeItem('currentUser'); // نحذف فقط session الحالي
    this.user.set(null);
    this.loggedIn.set(false);
    this.router.navigate(['/login']);
  }

  isLoggedIn(): boolean {
    return this.loggedIn();
  }

  getUser(): User | null {
    return this.user();
  }

  // جلب كل المستخدمين المسجلين (اختياري)
  getAllUsers(): User[] {
    const registered = localStorage.getItem('registeredUsers');
    return registered ? JSON.parse(registered) : [];
  }
}
