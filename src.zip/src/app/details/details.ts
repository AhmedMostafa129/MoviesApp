import { Component, OnInit } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ActivatedRoute, Router, NavigationEnd, RouterLink } from "@angular/router";
import { MoviesServices } from "../services/movies-services";
import { Category } from "../modals/category";
import { Showcatogry } from "../services/showcatogry";
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-mv-details',
  standalone: true,
  imports: [CommonModule,RouterLink],
  templateUrl: './details.html',
  styleUrls: ['./details.css'],
})
export class MvDetails implements OnInit {
  movie: any;
  category: Category[] = [];
  recommendedMovies: any[] = [];

  constructor(
    private route: ActivatedRoute,
    private moviesService: MoviesServices,
    private _showcatogry: Showcatogry,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.category = this._showcatogry.getAllcategory();
    
    // مراقبة تغير الـ route لتحديث الفيلم تلقائيًا
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => {
        this.loadMovie();
      });

    // تحميل أول مرة
    this.loadMovie();
  }

  loadMovie() {
    const idParam = this.route.snapshot.paramMap.get('id');
    if (idParam) {
      const id = Number(idParam);
      this.movie = this.moviesService.getMovieById(id);
      if (this.movie) {
        this.recommendedMovies = this.moviesService.getRecommendedMovies(this.movie.categoryId, this.movie.id);
      }
    }
  }

  getCategoryName(id: number) {
    const cat = this.category.find(c => c.id === id);
    return cat ? cat.name : 'Unknown';
  }

  goToMovie(id: number) {
    this.router.navigate(['/mvDetails', id]);
  }
}
