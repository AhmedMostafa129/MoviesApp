import { NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, RouterModule,NgClass],
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})
export class RegisterComponent {
  name = '';
  email = '';
  password = '';
  confirmPassword = '';
  showPassword = false;
  showConfirmPassword = false;

  constructor(private router: Router) {}

  togglePassword() {
    this.showPassword = !this.showPassword;
  }

  toggleConfirmPassword() {
    this.showConfirmPassword = !this.showConfirmPassword;
  }

 onRegister() {
  if (this.password !== this.confirmPassword) {
    alert('Passwords do not match!');
    return;
  }

  const newUser = {
    name: this.name,
    email: this.email,
    password: this.password
  };

  const existingUsers = JSON.parse(localStorage.getItem('registeredUsers') || '[]');

  const exists = existingUsers.find((u: any) => u.email === this.email);
  if (exists) {
    alert('Email already registered!');
    return;
  }

  existingUsers.push(newUser);
  localStorage.setItem('registeredUsers', JSON.stringify(existingUsers));

  localStorage.setItem('currentUser', JSON.stringify(newUser));

  alert('Registration successful!');
  this.router.navigate(['/account-details']);
}

}
