import { Component, signal, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth';
import { NgClass } from '@angular/common';

@Component({
  selector: 'app-account-details',
  standalone: true,
  imports: [FormsModule, NgClass], 
  templateUrl: './account-details.html',
  styleUrl: './account-details.css'
})
export class AccountDetailsComponent {
  private auth = inject(AuthService);

  user = signal(this.auth.getUser());

  name = this.user()?.name ?? '';
  oldPassword = '';      // كلمة السر القديمة
  newPassword = '';      // كلمة السر الجديدة
  showOldPassword = false;
  showNewPassword = false;

  logout() {
    this.auth.logout();
  }

  saveChanges() {
  const currentUser = this.user();
  if (!currentUser) return;

  let passwordToSave = currentUser.password;
  if (this.oldPassword || this.newPassword) {
    if (this.oldPassword !== currentUser.password) {
      alert('Old password is incorrect!');
      return;
    }

    if (this.newPassword === currentUser.password) {
      alert('New password cannot be the same as the old password!');
      return;
    }

    passwordToSave = this.newPassword;
  }

  const updatedUser = { ...currentUser, name: this.name, password: passwordToSave };

  this.user.set(updatedUser);
  localStorage.setItem('currentUser', JSON.stringify(updatedUser));

  const registered: any[] = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
  const index = registered.findIndex(u => u.email === currentUser.email);
  if (index !== -1) {
    registered[index] = updatedUser;
    localStorage.setItem('registeredUsers', JSON.stringify(registered));
  }

  alert('Your details have been updated!');
  this.oldPassword = '';
  this.newPassword = '';
}
}