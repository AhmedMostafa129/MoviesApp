import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { NgIf, NgClass } from '@angular/common';  // <-- هنا ضيف NgIf
import { AuthService } from '../../services/auth';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, RouterModule, NgIf, NgClass], // <-- ضيف NgIf هنا
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {
  private auth = inject(AuthService);
  private router = inject(Router);

  email = '';
  password = '';
  rememberMe = false;
  showPassword = false;
  errorMessage = '';

  constructor() {
    const remembered = localStorage.getItem('rememberedEmail');
    if (remembered) {
      this.email = remembered;
      this.rememberMe = true;
    }
  }

  togglePassword() {
    this.showPassword = !this.showPassword;
  }

  onLogin() {
    this.errorMessage = '';

    if (!this.email || !this.password) {
      this.errorMessage = 'Please enter email and password.';
      return;
    }

    const ok = this.auth.login(this.email.trim(), this.password);

    if (ok) {
      if (this.rememberMe) {
        localStorage.setItem('rememberedEmail', this.email.trim());
      } else {
        localStorage.removeItem('rememberedEmail');
      }

      this.router.navigate(['/account-details']);
    } else {
      this.errorMessage = 'Invalid email or password.';
    }
  }
}
