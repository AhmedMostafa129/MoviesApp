import { Component, input, OnChanges, SimpleChanges } from '@angular/core';
import { Movies } from '../modals/movies';
import { Input } from '@angular/core';
import { Showcatogry } from '../services/showcatogry';
import { Category } from '../modals/category';
import { Router, RouterLink } from '@angular/router';
import { MoviesServices } from '../services/movies-services';

@Component({
  selector: 'app-filmes',
  imports: [],
  templateUrl: './filmes.html',
  styleUrl: './filmes.css',
})
export class Filmes implements OnChanges {
  movie: Movies[];
  selectmov: Movies[];
  category: Category[];

  @Input() selectedfilmes: number = 0;
  @Input() searchText: string = '';

  constructor(
    private _showcatogry: Showcatogry,
    private _moviesServices: MoviesServices,
    private router: Router
  ) {
    this.movie = this._moviesServices.getAllmovies();
    this.selectmov = this.movie;
    this.category = this._showcatogry.getAllcategory();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['selectedfilmes'] || changes['searchText']) {
      this.selectedMoves();
    }
  }

  getCategoryName(id: number) {
    const cat = this.category.find(c => c.id === id);
    return cat ? cat.name : 'Unknown';
  }

  selectedMoves() {
    let filtered =
      this.selectedfilmes == 0
        ? this.movie
        : this.movie.filter(i => i.categoryId == this.selectedfilmes);

    if (this.searchText && this.searchText.trim() !== '') {
      const searchLower = this.searchText.toLowerCase();
      filtered = filtered.filter(i =>
        i.name.toLowerCase().includes(searchLower)
      );
    }

    this.selectmov = filtered;
  }

  // ✅ الزرار هيستدعي الميثود دي
  goToDetails(id: number) {
    this.router.navigate(['/mvDetails', id]);
  }
}
